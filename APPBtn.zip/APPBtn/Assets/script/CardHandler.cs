using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CardHandler : MonoBehaviour
{

    public Image Image_ShopItem;

    public Text Text_Amount;

    public Text Text_Product;

    public Text Text_Cost;

    private int _amount = 0;


    /// <summary>
    /// �]�i��諸�ܼơA�Y�X�ƤF�N���m
    /// </summary>
    public int Amount
    {
        get { return _amount; }
        set
        {
            _amount = value;
            _isDirty = true;
        }
    }

    private Sprite _shopItem;

    public Sprite ShopItem
    {
        get { return ShopItem; }
        set
        {
            _shopItem = value;
            _isDirty = true;
        }
    }

    private string _product;

    public string Product
    {
        get { return _product; }
        set
        {
            _product = value;
            _isDirty = true;
        }
    }

    private int _cost = 0;

    public int Cost
    {
        get { return _cost; }
        set
        {
            _cost = value;
            _isDirty = true;
        }
    }
    /// <summary>
    /// �]�i��諸�ܼơA�Y�X�ƤF�N���m
    /// </summary>

    private bool _isDirty = false; 

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (_isDirty) //�H���ˬd�A��粒�F�N�ۧ�����
        {
            Text_Amount.text = _amount.ToString();
            Text_Product.text = _product.ToString();
            Text_Cost.text = _cost.ToString();
            if (_shopItem != null)
            {
                Image_ShopItem.sprite = _shopItem;
            }


            _isDirty = false;
        }
    }
}
