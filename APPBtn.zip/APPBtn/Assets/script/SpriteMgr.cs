using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpriteMgr : MonoBehaviour
{
    public Sprite[] sprites; //���ɰ}�C
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
