using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ShopMgr : MonoBehaviour
{
    public CardHandler cardHandler;
    public SpriteMgr spriteMgr;


    public GameObject prefabSource;
    public GameObject pool;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnGUI()
    {
        if(GUI.Button(new Rect(10, 70, 50, 30), "Click"))
        {
            cardHandler.Amount = 777;
            cardHandler.Product = "very useless";
            cardHandler.Cost = 999;
            cardHandler.ShopItem = spriteMgr.sprites[0]; //spritedata
        }

        if (GUI.Button(new Rect(10, 100, 50, 30), "+"))
        {
            GameObject target = Instantiate(prefabSource); //prefab��Ҥ�
            target.transform.parent = pool.transform; //��h�����O
            target.transform.localScale = Vector3.one; //reset

            //fill data
            CardHandler _card = target.GetComponent<CardHandler>();
            _card.Amount = Random.Range(100, 999);
            _card.ShopItem = spriteMgr.sprites[Random.Range(0, 6)];
            _card.Product = "useless thing" + Random.Range(1, 7);
            _card.Cost = Random.Range(100, 9999);
        }
    }
}
